# ComicCraft — AI-ML & GEN-AI Track Submission

This folder follows the phase/folder and document naming structure of the supplied AI-ML & GEN-AI Track Project Template.

## Primary project
The original `Comic-Craft-main` source remains the primary project. Its application files, README, tests, requirements and `ComicCraft documentation.docx` are retained.

## Project data retained
- Project Name: Comic Craft-AI
- Team ID: SWTID-2026-8849
- Team Leader: Jennet Mercy A (jennetmercy18@gmail.com)
- Team Member: Prasanna P (danielprasanna15@gmail.com)
- Team Member: Sadana S (sadhanaasathishh@gmail.com)
- Team Member: Sadana D (bujima1903@gmail.com)
- Team Member: Anushiya A (anushiyaa687@gmail.com)

The submission PDFs were populated from the supplied ComicCraft documentation and source structure. No existing ComicCraft source file was replaced.

## Evidence
Where available, screenshots and the architecture/folder-structure images from `ComicCraft documentation.docx` are embedded in the relevant submission PDFs.
